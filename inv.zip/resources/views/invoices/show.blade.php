@extends('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('layouts.navbars.auth.topnav')
    <div class="container-fluid py-4">
        <div class="row mt-4 mx-4">
            <div class="col-12">
                <div class="card mb-3">
                    <div class="card-header">
                        <h4>Detail Receipt untuk Invoice #{{ $receipt->invoice->invoice_number }}</h4>
                    </div>
                    <div class="card-body">
                        <p><strong>Amount Paid:</strong> Rp{{ number_format($receipt->amount_paid, 2) }}</p>
                        <p><strong>Payment Method:</strong> {{ $receipt->payment_method }}</p>
                        <p><strong>Status:</strong> <span
                                class="badge bg-{{ $receipt->status == 'Disetujui' ? 'success' : ($receipt->status == 'Ditolak' ? 'danger' : 'warning') }}">{{ $receipt->status }}</span>
                        </p>

                        @if ($receipt->status === 'Ditolak')
                            <p><strong>Alasan Penolakan:</strong> {{ $receipt->rejection_reason }}</p>
                        @endif

                        <hr>

                        @if (in_array($receipt->status, ['Draft', 'Menunggu Approval']))
                            <h5>Approval Receipt</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <form action="{{ route('receipts.approve', $receipt->id) }}" method="POST">
                                        @csrf
                                        <div class="mb-3">
                                            <label for="approval_reason" class="form-label">Alasan Approval</label>
                                            <textarea name="approval_reason" class="form-control" required minlength="10"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success">Approve</button>
                                    </form>
                                </div>
                                <div class="col-md-6">
                                    <form action="{{ route('receipts.reject', $receipt->id) }}" method="POST">
                                        @csrf
                                        <div class="mb-3">
                                            <label for="rejection_reason" class="form-label">Alasan Penolakan</label>
                                            <textarea name="rejection_reason" class="form-control" required minlength="10"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-danger">Reject</button>
                                    </form>
                                </div>
                            </div>
                        @endif

                        @if ($receipt->status === 'Disetujui')
                            <hr>
                            <h4>Download Receipt</h4>
                            <p>Scan QR Code untuk mengunduh PDF Receipt:</p>
                            <img src="{{ asset('storage/qrcodes/receipt-' . $receipt->id . '.png') }}" alt="QR Code"
                                width="150">
                            <br>
                            <a href="{{ route('receipts.download', $receipt->id) }}" class="btn btn-success mt-3">Unduh
                                PDF</a>
                        @endif

                        <a href="{{ route('receipts.index') }}" class="btn btn-secondary mt-3">Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection
