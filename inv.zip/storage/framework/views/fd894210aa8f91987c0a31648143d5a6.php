

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.auth.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <div class="container-fluid py-4">
        <div class="row mt-4 mx-4">
            <div class="col-12">
                <?php if(session('success')): ?>
                    <div class="alert alert-success text-white" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="card mb-4 ">
                    <div class="card-header">
                        <h4>User
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create user')): ?>
                            <a href="<?php echo e(url('users/create')); ?>" class="btn btn-primary float-end">Add User</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2 px-4">
                        <div class="table-responsive p-0">
                            <table class="table table-striped align-items-center mb-0" id="dataTableUser">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-sm font-weight-bolder opacity-7">No.
                                        </th>
                                        <th class="text-uppercase text-secondary text-sm font-weight-bolder opacity-7">Name
                                        </th>
                                        <th class="text-uppercase text-secondary text-sm font-weight-bolder opacity-7">
                                            Email
                                        </th>
                                        <th class="text-uppercase text-secondary text-sm font-weight-bolder opacity-7">
                                            Roles
                                        </th>
                                        
                                        <th
                                            class="text-center text-uppercase text-secondary text-sm font-weight-bolder opacity-7">
                                            Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td>
                                                <div class="d-flex px-3 py-1">
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($loop->iteration); ?></h6>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex px-3 py-1">
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($user->username); ?></h6>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex px-3 py-1">
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($user->email); ?></h6>
                                                    </div>
                                                </div>
                                            </td>

                                            <td>
                                                <?php if($user->roles->isNotEmpty()): ?>
                                                    <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-primary"><?php echo e($role); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">No role assigned</span>
                                                <?php endif; ?>
                                            </td>

                                            <td class="align-middle text-end">
                                                <div class="d-flex px-3 py-1 justify-content-center align-items-center ">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update user')): ?>
                                                        <a href="<?php echo e(url('users/' . $user->id . '/edit')); ?>"
                                                            class="btn btn-success font-weight-bold mb-0 me-2">Edit</a>
                                                    <?php endif; ?>

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete user')): ?>
                                                        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST"
                                                            onsubmit="return confirm('Are you sure?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit"
                                                                class="btn btn-danger font-weight-bold mb-0">Delete</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    <script src="https://cdn.datatables.net/2.2.1/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.2.1/js/dataTables.bootstrap5.js"></script>

    <script>
        new DataTable('#dataTableUser');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inv\resources\views/role-permission/user/index.blade.php ENDPATH**/ ?>