<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.auth.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row mt-4 mx-4">
            <div class="col-12">
                <div class="card mb-3">
                    <div class="card-header">
                        <h4>Detail Receipt untuk Invoice #<?php echo e($receipt->invoice->invoice_number); ?></h4>
                    </div>
                    <div class="card-body">
                        <p><strong>Amount Paid:</strong> Rp<?php echo e(number_format($receipt->amount_paid, 2)); ?></p>
                        <p><strong>Payment Method:</strong> <?php echo e($receipt->payment_method); ?></p>
                        <p><strong>Status:</strong> <span
                                class="badge bg-<?php echo e($receipt->status == 'Disetujui' ? 'success' : ($receipt->status == 'Ditolak' ? 'danger' : 'warning')); ?>"><?php echo e($receipt->status); ?></span>
                        </p>

                        <?php if($receipt->status === 'Ditolak'): ?>
                            <p><strong>Alasan Penolakan:</strong> <?php echo e($receipt->rejection_reason); ?></p>
                        <?php endif; ?>

                        <hr>

                        <?php if(in_array($receipt->status, ['Draft', 'Menunggu Approval'])): ?>
                            <h5>Approval Receipt</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <form action="<?php echo e(route('receipts.approve', $receipt->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="approval_reason" class="form-label">Alasan Approval</label>
                                            <textarea name="approval_reason" class="form-control" required minlength="10"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success">Approve</button>
                                    </form>
                                </div>
                                <div class="col-md-6">
                                    <form action="<?php echo e(route('receipts.reject', $receipt->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="rejection_reason" class="form-label">Alasan Penolakan</label>
                                            <textarea name="rejection_reason" class="form-control" required minlength="10"></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-danger">Reject</button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if($receipt->status === 'Disetujui'): ?>
                            <hr>
                            <h4>Download Receipt</h4>
                            <p>Scan QR Code untuk mengunduh PDF Receipt:</p>
                            <img src="<?php echo e(asset('storage/qrcodes/receipt-' . $receipt->id . '.png')); ?>" alt="QR Code"
                                width="150">
                            <br>
                            <a href="<?php echo e(route('receipts.download', $receipt->id)); ?>" class="btn btn-success mt-3">Unduh
                                PDF</a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('receipts.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inv\resources\views/invoices/show.blade.php ENDPATH**/ ?>